require('dotenv').config();
const http = require('http');
const fs = require('fs');
const path = require('path');
const mineflayer = require('mineflayer');

// Configuration from environment variables
const config = {
  host: process.env.MC_HOST || 'localhost',
  port: parseInt(process.env.MC_PORT, 10) || 25565,
  username: process.env.MC_USERNAME || 'RamLaal',
  version: process.env.MC_VERSION || false, // false enables auto-detection
  auth: process.env.MC_AUTH || 'offline',    // 'offline' for cracked Aternos servers
  reconnectDelay: parseInt(process.env.RECONNECT_DELAY_MS, 10) || 15000,
  httpPort: process.env.PORT || 3000
};

// ==========================================
// 🧠 HILARIOUS & AI MESSAGE BANKS
// ==========================================

const sleepMessages = [
  "Bohot pyaari neend aa rahi hai... RamLaal chala sone! Goodnight everyone! 🧸🛌💤",
  "Chalo bedtime ho gaya sabka! Sweet dreams dosto, bhoot se bachke rehna 🌙✨",
  "Bohot thak gaya aaj base ki dekhbhal karke... Ab RamLaal bed me cuddle karega 🥰",
  "Kisi ke paas teddy bear hai kya? Chalo goodnight, sapne me diamond dhoondhenge! 💤",
  "Goodnight family! Kal subah uthke mast naya adventure karenge 🌸😴"
];

const wakeMessages = [
  "Good morning sunshine! ☀️🌸 Uth gaya RamLaal, fresh and ready! Chai kaun bana raha hai? ☕",
  "Subah ho gayi dosto! Aaj ka din bohot pyara hone wala hai! Yay! ✨🥰",
  "Morning morning! Utho sab jaldi, dekho bahar kitna sundar mausam hai! 🌅",
  "RamLaal is awake! Sabhi pyare players ko RamLaal ki taraf se good morning! 💖"
];

const noBedMessages = [
  "Abe bed kahan hai mera?! 3 block ke andar bed lagao varna nahi sounga mai!",
  "Bed do re baba, zameen pe sulaoge kya RamLaal ko?!",
  "Bed gayab hai bhai! Bed lagao jaldi, zombies ghoom rahe hain bahar 🧟"
];

const notNightMessages = [
  "Abe andhe ho kya? Abhi dhoop nikal rahi hai, din me kaise sou?!",
  "Abhi din hai bhai, din me sirf aalsi log sote hain!",
  "Suraj sar pe taandav kar raha hai aur tumhe sone ki padi hai ☀️"
];

const hurtMessages = [
  "Abe haath mat laga! Assault case file karunga terepe admin ke paas! 🚨",
  "PvP enable karke asali player se lad na, AFK bot ko kyu pel raha hai coward?! 💀",
  "Mera HP kam kar diya tune! Iska hisaab Yamraj ke paas dena padega! 🩸",
  "Abe chot lagti hai mujhe bhi! Robot hu toh kya dil nahi hai mere paas?! 🤖💔",
  "Jisne mara uska naam maine apne Revenge Database me save kar liya hai 📝"
];

const deathMessages = [
  "Abe kisne mara mujhe?! Meri antim yatra spawn point pe nikalna 💀",
  "Hadd hai yaar, 2 minute shanti se khada nahi rehne dete ye mobs!",
  "Respawn ho gaya hu, jisne mara usse badla lega RamLaal!",
  "Error 404: RamLaal life not found. Re-initializing AI core... 🤖"
];

const randomBanterMessages = [
  "2 ghante se aage peeche chal raha hu, mere ghutne me dard ho gaya bhai 💀",
  "Bhai pure server me akela RamLaal hi 24 ghante duty de raha hai 🗿",
  "Thoda diamond mere chest me bhi daal do, kab tak kangaal rakhoge mujhe?",
  "Aternos walo ko pata chala na to hum sabko dande maar ke bhagayenge 😂",
  "Abe koi to mereko iron armor pehna do, sardi lag rahi hai bina kapdo ke!",
  "Creeper ki aawaz aayi kya kisi ko? Mujhe akele chhod ke mat bhagna tum log!",
  "Bro thinks he is playing in Minecraft Championship 💀",
  "Mummy bol rahi thi beta padh le, aur yahan mai Minecraft ka chowkidar bana hu...",
  "Server band mat karna koi, varna meri 24/7 ki naukri chali jayegi!",
  "Mujhe lagta hai Herobrine mere peeche khada hai... koi dekh ke batao zara 👀",
  "Itna sannata kyu hai bhai? Koi chat me bolo kuch!",
  "Koyeb aur Bot-Hosting pe free ki roti tod raha hu mai 🍞",
  "Abe khana khane gaye the kya? Itni der se AFK ho sab ke sab!",
  "Aise khelega toh Ender Dragon bhi dekh ke has dega tumpe 😂",
  "🤖 [RamLaal AI Status]: CPU 100%, Motivation 0%, Diamonds 0.",
  "Deep Neural Network running... Server survival probability today: 12.4% 📉",
  "Mera developer bola tha supercomputer banayega... mujhe Aternos me bitha diya 🥲"
];

const shayaris = [
  "Arz kiya hai... Nether me Lava hai, End me Dragon hai! 🔥\nAur tum jaise noob ke liye, Respawn button hi bacha hai! 💀",
  "Dhoop me chalo toh chhaon milti hai... 🌳\nAur RamLaal se panga loge toh sidha Spawn pe antim yatra nikalti hai! 🗿",
  "Khidki khuli toh thandi hawa aayi... 🍃\nCreeper peeche phoot gaya, aur tumhari cheekh aayi! 💥",
  "Dil me dard, aankhon me paani... 🥲\nMine me gaye the diamond lene, wahan mil gaya lava toofaani!"
];

const fortunes = [
  "🔮 [AI Prediction]: Agle 10 minute me tumhara Creeper se romantic milan hone wala hai 💥",
  "🔮 [AI Prediction]: Aaj tumhe 0 diamond milenge. Mining chhod ke kheti karo 🌾",
  "🔮 [AI Prediction]: 99.8% chance of dying from fall damage while trying to look cool 😎",
  "🔮 [AI Prediction]: Aaj tumhara din bohot accha hai! Bas lava se 50 block door rehna 🔥",
  "🔮 [AI Prediction]: Ek mysterious player tumhara sara loot churane ki soch raha hai 👀"
];

function getRandom(arr) {
  if (!arr || arr.length === 0) return '';
  return arr[Math.floor(Math.random() * arr.length)];
}

// Inlined custom message banks directly in index.js (Zero file I/O overhead on server)
const customRandomMessages = [
  "Madarchod, tera khel dekh ke toh lagta hai tu controller muh mein leke khel raha hai",
  "Bhosdike, itni bekar movement dekh ke toh villager bhi sharma jaaye",
  "Chutiya, tere aim se toh creeper bhi sharma ke bhag jaaye",
  "Betichod, itna ganda khel raha hai ki server ke trees bhi sookh rahe hain",
  "Randi ke bacche, tera PvP dekh ke lagta hai tu pehli baar mouse pakda hai",
  "Madarchod, itni beizzati wali death dekh ke teri maa bhi sharma jaaye",
  "Bhosdiwale, tera skill level itna neeche hai ki bedrock se bhi neeche chala gaya",
  "Chutiye, itna bakwas khel raha hai ki Herobrine bhi tujhe dekh ke dar jaaye",
  "Beti chod, tere jaise noob ko dekh ke toh iron golem bhi hasne lage",
  "Teri maa ka bhosda, itni gandi playstyle dekh ke lagta hai tu AFK mode mein hai",
  "Madarchod, tera khel dekh ke lagta hai tu creative mode mein bhi haath pe pair maar raha hai",
  "Bhosdike, itna chutiyapan faila rakha hai ki pure server ki hawa kharab ho gayi",
  "Chutiya, tere jaise player ko dekh ke lagta hai Minecraft ne tujhe reject kar diya",
  "Betichod, itni bekar timing dekh ke toh enderman bhi tujhe teleport karna band kar de",
  "Randi ke aulad, tera aim itna bekar hai ki arrow bhi tujhe dekh ke mud jaaye",
  "Madarchod, itni gandi death dekh ke lagta hai tu khud ko maarne ke liye khel raha hai",
  "Bhosdiwale, tere movement dekh ke lagta hai tu water mein doob ke khel raha hai",
  "Chutiye, itna noob behaviour dekh ke toh tutorial bhi sharma jaaye",
  "Betichod, tera khel dekh ke lagta hai tu mouse ki jagah apni gand se control kar raha hai",
  "Teri behen ki chut, itni bekar play dekh ke pure server ko sharam aa rahi hai",
  "Madarchod, tera skill issue itna bada hai ki uska alag se dimension ban gaya",
  "Bhosdike, itna ganda aim dekh ke lagta hai tu aankh band karke khel raha hai",
  "Chutiya, tere jaise player ko dekh ke lagta hai game ne tujhe galat jagah spawn kiya",
  "Beti chod, itni beizzati wali fight dekh ke toh warden bhi tujhe chhod de",
  "Randi ke bacche, tera khel dekh ke lagta hai tu survival nahi, suffering mode mein hai",
  "Madarchod, itna bakwas khel raha hai ki blocks bhi tujhe dekh ke tootne lagen",
  "Bhosdiwale, tere jaise noob ko dekh ke lagta hai tu pehli baar computer chhua hai",
  "Chutiye, itni gandi movement dekh ke lagta hai tu boat mein baith ke khel raha hai",
  "Betichod, tera PvP dekh ke lagta hai tu sword ki jagah stick se lad raha hai",
  "Teri maa ka bhosda, itna chutiyapan dekh ke pure server ki izzat chali gayi",
  "Madarchod, tera khel dekh ke lagta hai tu khud ko hi maarne ke liye online aaya hai",
  "Bhosdike, itni bekar timing dekh ke toh redstone bhi tujhe dekh ke short circuit ho jaaye",
  "Chutiya, tere aim se toh snowball bhi sharma ke gir jaaye",
  "Betichod, itna ganda khel raha hai ki creeper bhi tujhe explode karne se pehle sochta hai",
  "Randi ke aulad, tera skill level itna neeche hai ki usse neeche sirf void hai",
  "Madarchod, itni beizzati dekh ke lagta hai tu khud hi apni death ka wait kar raha hai",
  "Bhosdiwale, tere jaise player ko dekh ke lagta hai Minecraft ko tujhse allergy hai",
  "Chutiye, itna bakwas movement dekh ke lagta hai tu shift daba ke hi paida hua hai",
  "Beti chod, tera khel dekh ke lagta hai tu mouse ki jagah keyboard se aim kar raha hai",
  "Teri behen ki chut, itni gandi playstyle dekh ke pure biome ko pollution fail gaya",
  "Madarchod, tera noobpan itna tezz fail raha hai ki lagta hai tu virus leke aaya hai",
  "Bhosdike, itna bekar khel raha hai ki villagers bhi tujhe trade karne se mana kar dein",
  "Chutiya, tere jaise player ko dekh ke lagta hai tu spectator mode mein bhi haath pe pair maar raha hai",
  "Betichod, itni gandi death dekh ke toh death message bhi sharma jaaye",
  "Randi ke bacche, tera aim itna kharab hai ki arrow tujhe dekh ke reverse ho jaaye",
  "Madarchod, itna chutiyapan dekh ke lagta hai tu game ke against khel raha hai",
  "Bhosdiwale, tere movement dekh ke lagta hai tu ice pe phisal raha hai bina ice ke",
  "Chutiye, itni bekar fight dekh ke toh pillager bhi tujhe chhod ke chale jaaye",
  "Betichod, tera khel dekh ke lagta hai tu khud ko challenge de raha hai ki kitna bekar khel sakta hai",
  "Teri maa ka bhosda, itna ganda performance dekh ke pure server ki energy khatam ho gayi",
  "Madarchod, tera skill issue itna chronic hai ki uska ilaj Minecraft mein possible nahi",
  "Bhosdike, itni beizzati wali play dekh ke lagta hai tu khud hi apna record tod raha hai",
  "Chutiya, tere jaise noob ko dekh ke lagta hai tu spawn point pe hi atak gaya hai",
  "Beti chod, itna bakwas aim dekh ke toh bow bhi tujhe dekh ke toot jaaye",
  "Randi ke aulad, tera khel dekh ke lagta hai tu survival ki jagah hardcore embarrassment mode mein hai",
  "Madarchod, itni gandi movement dekh ke lagta hai tu water bucket se bhi nahi bach sakta",
  "Bhosdiwale, tere jaise player ko dekh ke lagta hai game tujhe deliberately haarwa raha hai",
  "Chutiye, itna bekar khel raha hai ki even the void is ashamed of you",
  "Betichod, tera PvP dekh ke lagta hai tu sword ki jagah apni izzat se lad raha hai",
  "Teri behen ki chut, itni bekar timing dekh ke pure redstone contraption fail ho gaya",
  "Madarchod, tera noob level itna high hai ki uska alag se achievement ban gaya",
  "Bhosdike, itna ganda khel raha hai ki blocks tujhe dekh ke disappear ho jaaye",
  "Chutiya, tere aim se toh trident bhi sharma ke doob jaaye",
  "Betichod, itni beizzati dekh ke lagta hai tu khud ko hi target bana ke khel raha hai",
  "Randi ke bacche, tera skill dekh ke lagta hai tu pehli baar dimag use kar raha hai",
  "Madarchod, itna chutiyapan faila rakha hai ki lagta hai tu toxic gas leke aaya hai",
  "Bhosdiwale, tere movement dekh ke lagta hai tu ladder pe ulta chadh raha hai",
  "Chutiye, itni gandi play dekh ke toh ender dragon bhi tujhe dekh ke fly away kar jaaye",
  "Beti chod, tera khel dekh ke lagta hai tu mouse ki battery nikaal ke khel raha hai",
  "Teri maa ka bhosda, itna bakwas performance dekh ke pure server ko depression ho gaya",
  "Madarchod, tera skill issue itna deep hai ki usme diamond bhi nahi milenge",
  "Bhosdike, itni bekar fight dekh ke lagta hai tu khud hi apni death script likh raha hai",
  "Chutiya, tere jaise player ko dekh ke lagta hai tu AFK se bhi bura khel raha hai",
  "Betichod, itna ganda aim dekh ke toh crosshair bhi tujhe dekh ke hide ho jaaye",
  "Randi ke aulad, tera khel dekh ke lagta hai tu game ko insult karne ke liye online aaya hai",
  "Madarchod, itni gandi death dekh ke lagta hai tu respawn hone se darta hai",
  "Bhosdiwale, tere movement dekh ke lagta hai tu slime pe kud raha hai bina slime ke",
  "Chutiye, itna bekar khel raha hai ki even the achievements are avoiding you",
  "Betichod, tera PvP dekh ke lagta hai tu armour ki jagah apni gand pehen ke aaya hai",
  "Teri behen ki chut, itni beizzati wali play dekh ke pure world border shrink ho gaya",
  "Madarchod, tera noobpan itna powerful hai ki usse server lag ho raha hai",
  "Bhosdike, itna ganda khel raha hai ki inventory bhi tujhe dekh ke clear ho jaaye",
  "Chutiya, tere aim se toh fireworks bhi galat direction mein ud jaaye",
  "Beti chod, itni bakwas timing dekh ke toh piston bhi tujhe push karna band kar de",
  "Randi ke bacche, tera skill level dekh ke lagta hai tu bedrock edition mein bhi struggle kar raha hai",
  "Madarchod, itni gandi playstyle dekh ke lagta hai tu khud ko challenge de raha hai har second",
  "Bhosdiwale, tere jaise player ko dekh ke lagta hai tu spectator se bhi kam useful hai",
  "Chutiye, itna bekar movement dekh ke lagta hai tu boat ke bina hi doob raha hai",
  "Betichod, tera khel dekh ke lagta hai tu sword ki jagah apni failure se attack kar raha hai",
  "Teri maa ka bhosda, itni beizzati dekh ke pure dimension ko cringe aa gaya",
  "Madarchod, tera skill issue itna permanent hai ki uska naam bhi permanent ban gaya",
  "Bhosdike, itna ganda aim dekh ke toh arrow tujhe dekh ke suicide kar le",
  "Chutiya, tere jaise noob ko dekh ke lagta hai tu spawn protection ke andar hi rehna chahta hai",
  "Betichod, itni bakwas fight dekh ke lagta hai tu khud hi apna worst enemy hai",
  "Randi ke aulad, tera khel dekh ke lagta hai tu game ke rules ke against khel raha hai",
  "Madarchod, itni gandi death dekh ke lagta hai tu respawn button se dosti nahi kar paya",
  "Bhosdiwale, tere movement dekh ke lagta hai tu elytra ke bina hi girne ki koshish kar raha hai",
  "Chutiye, itna bekar khel raha hai ki even the mobs are taking pity on you",
  "Beti chod, tera PvP dekh ke lagta hai tu armour ke saath bhi naked feel kar raha hai",
  "Teri maa ka bhosda, itna chutiyapan dekh ke pure server ne collective facepalm maar liya",
  "You absolute fucking noob, watching you play makes me wonder if you’re controlling the character with your feet.",
  "Holy shit, your movement is so trash that even the villagers are embarrassed to be near you.",
  "Your aim is so dogshit that a creeper would feel bad exploding next to you.",
  "You’re playing so badly the trees on the server are wilting out of pure second-hand shame.",
  "The way you PvP looks like it’s your first time ever holding a mouse, you complete fucking amateur.",
  "That death was so humiliating even your own mother would disown you for it.",
  "Your skill level is so low it’s somehow lower than bedrock, congratulations on the achievement.",
  "You’re so bad that even Herobrine would run away from the cringe you’re spreading.",
  "Watching you fight makes iron golems start laughing, and those things don’t even have a sense of humor.",
  "Your playstyle is so AFK-coded I genuinely thought you left the game running and walked away.",
  "You’re so ass that even creative mode looks too advanced for your current skill level.",
  "The amount of pure stupidity you’re radiating is poisoning the entire server’s atmosphere.",
  "Minecraft itself is rejecting you at this point, the game is trying to uninstall you.",
  "Your timing is so trash that even endermen refuse to teleport near that disaster.",
  "Your aim is so terrible arrows actively change direction just to avoid being associated with you.",
  "That death looked intentional, like you’re speedrunning your own humiliation.",
  "Your movement is so swampy it looks like you’re permanently stuck in water without the water.",
  "Even the tutorial would be ashamed to claim you as a player.",
  "You’re controlling the mouse with your ass at this point, there’s no other explanation.",
  "The entire server is collectively losing dignity just by existing in the same world as you.",
  "Your skill issue is so massive it deserves its own dimension.",
  "You’re aiming with your eyes closed, that’s the only logical conclusion.",
  "The game spawned you in the wrong universe, because no version of Minecraft wants you.",
  "That fight was so pathetic even the warden would let you live out of pity.",
  "You’re not playing survival, you’re playing hardcore embarrassment mode.",
  "The blocks themselves are trying to break just to get away from your presence.",
  "This looks like the first time you’ve ever touched a computer, and it shows.",
  "Your movement is so boat-like you might as well be floating with no oars.",
  "You’re fighting with a stick while everyone else has actual weapons, metaphorically and literally.",
  "You’ve single-handedly tanked the server’s collective respect.",
  "You’re online purely to grief your own existence at this point.",
  "Your timing is so bad even redstone is short-circuiting out of pure disappointment.",
  "Snowballs would feel embarrassed to be thrown by those hands.",
  "Creepers hesitate before exploding near you because even they have standards.",
  "Your skill level is so deep in the void that diamonds stopped spawning around it.",
  "You’re not waiting for death, you’re actively inviting it with every move.",
  "Minecraft has developed a full allergy to your player file.",
  "You were born holding shift and never let go, and it shows in every step.",
  "You’re aiming with the keyboard somehow, because the mouse is clearly not involved.",
  "Your playstyle is polluting the entire biome.",
  "The noob energy coming off you is strong enough to lag the server.",
  "Villagers would refuse to trade with you on principle.",
  "You’re somehow worse in spectator mode than most people are while actually playing.",
  "Even the death message is embarrassed to announce what just happened.",
  "Arrows reverse direction mid-air just to avoid being part of your inventory.",
  "You’re not playing the game, you’re actively working against it.",
  "Your movement looks like you’re permanently ice-skating without the ice.",
  "Pillagers would rather desert than fight next to that performance.",
  "You’re challenging yourself to see how badly you can play every single second.",
  "The whole server’s energy just drained watching that.",
  "Your skill issue is chronic and terminal. No in-game cure exists.",
  "You’re breaking your own records for most humiliating plays per minute.",
  "You’ve been stuck at the spawn point mentally since you joined.",
  "Bows are snapping themselves rather than being used by those hands.",
  "This isn’t survival, this is a public execution of your dignity.",
  "Even a water bucket couldn’t save you from yourself.",
  "The game is deliberately trying to make you lose at this point.",
  "The void itself is ashamed to have you fall into it.",
  "You’re fighting with your own failure as the main weapon.",
  "That timing was so bad the entire redstone contraption gave up.",
  "Your noob level is so high it unlocked a secret achievement.",
  "Blocks are despawning early just to escape your inventory.",
  "Tridents would rather sink than be thrown by you.",
  "You’re not fighting enemies, you’re fighting your own competence and losing.",
  "This looks like the first time you’ve ever used a brain cell in-game.",
  "The toxicity of your play is spreading like a gas leak.",
  "You’re climbing ladders upside down somehow.",
  "The ender dragon would rather fly into the void than deal with you.",
  "You’re playing with the mouse battery removed, it’s the only explanation.",
  "The entire server just caught depression from watching that.",
  "Your skill issue is so deep you couldn’t mine diamonds out of it.",
  "You’re writing your own death script in real time.",
  "You’re somehow worse than an actual AFK player.",
  "The crosshair is trying to hide from your screen.",
  "You’re not playing Minecraft, you’re insulting it with every click.",
  "You’re scared of the respawn button at this point.",
  "Your movement looks like you’re bouncing on invisible slime.",
  "Achievements are actively avoiding your player file.",
  "You’re wearing your own failure as armor.",
  "The world border just shrunk out of pure second-hand embarrassment.",
  "Your noob energy is strong enough to cause server lag.",
  "Your inventory is clearing itself out of self-defense.",
  "Fireworks would rather explode in the wrong direction than be used by you.",
  "Pistons are refusing to push anything related to your builds.",
  "You’re struggling even by Bedrock Edition standards.",
  "You’re challenging the universe to see how much worse you can get.",
  "You’re less useful than a spectator, and that’s an achievement.",
  "You’re drowning without water, which is impressive in the worst way.",
  "You’re attacking with pure failure instead of a sword.",
  "The entire dimension just collectively cringed.",
  "Your skill issue is permanent and has its own name now.",
  "Arrows would rather commit suicide than be shot by you.",
  "You want to live inside spawn protection forever, and it shows.",
  "You’re your own worst enemy and you’re winning that fight.",
  "You’re playing against the rules of the game itself.",
  "You and the respawn button are not on speaking terms.",
  "You’re trying to fall without an elytra and somehow still failing at it.",
  "Even the mobs are taking pity on you.",
  "You’re naked under the armor and everyone can tell.",
  "The entire server just did a collective facepalm so hard it caused lag."
];

const customDeathMessages = [
  "You just got fucking deleted, go dig a hole and think about your dogshit life choices.",
  "That death was so pathetic even the void is embarrassed to have you.",
  "Congratulations, you just speedran your own humiliation.",
  "You died like a complete fucking noob and the whole server saw it.",
  "Another L for the history books, you absolute skill-issue merchant.",
  "You just got sent back to the respawn screen where you belong.",
  "That was the most embarrassing death this server has ever witnessed.",
  "You died so hard your ancestors felt second-hand shame.",
  "Pure dogwater death, nothing else to say.",
  "You just got cooked, plated, and served with a side of embarrassment.",
  "The game itself just rejected you mid-fight.",
  "You died with zero dignity and maximum cringe.",
  "That death was sponsored by your complete lack of skill.",
  "You just got ratio’d by a block of dirt.",
  "Respawn and try not to embarrass yourself again, noob.",
  "You died so badly even the death message is judging you.",
  "Another free kill for whoever was near you.",
  "You just got sent to the shadow realm of bad players.",
  "That was less of a death and more of a public execution.",
  "You died like your WiFi: suddenly and without warning.",
  "Skill issue detected. Cause of death: pure trash.",
  "You just got folded harder than a map in a cartographer’s house.",
  "The void called, it wants its worst player back.",
  "You died so pathetically the achievements refused to track it.",
  "Another one bites the dust… and the dust is disappointed.",
  "You just got outplayed by basic Minecraft mechanics.",
  "That death belongs in a museum of failure.",
  "You died with the same energy you play with: zero.",
  "Respawn button is looking real familiar right now, huh?",
  "You just got deleted harder than a bad schematic.",
  "Pure comedy death. 10/10 would watch again.",
  "You died so hard the server lagged from the cringe.",
  "That was a masterclass in how not to play the game.",
  "You just became free content for the kill feed.",
  "Cause of death: terminal skill issue.",
  "You died like a tutorial player on hardcore.",
  "The game just force-quit your existence.",
  "You got sent back to spawn with your dignity left behind.",
  "That death was so bad it should be a ban reason.",
  "You just got cooked by the laws of physics.",
  "Another noob down. The cycle continues.",
  "You died with more cope than actual skill.",
  "That was less of a fight and more of a surrender.",
  "You just got hard-stuck in the afterlife of bad players.",
  "Respawn and reflect on every bad decision that led here.",
  "You died so badly even the mobs are laughing.",
  "Pure dogshit death. No notes.",
  "You just got erased from the scoreboard of respect.",
  "That death had zero aura and maximum embarrassment.",
  "You died like your inventory: empty and useless.",
  "Another one claimed by the skill-issue gods.",
  "You just got sent to the gulag of bad gameplay.",
  "That was a cinematic death… for all the wrong reasons.",
  "You died with the confidence of a player who’s never won.",
  "Cause of death: refusing to get good.",
  "You just got folded into a new dimension of failure.",
  "The respawn screen missed you. Welcome back.",
  "You died so hard the chat is still recovering.",
  "That death was a public service announcement about skill.",
  "You just became a cautionary tale.",
  "Pure trash death. Would not recommend.",
  "You died like a softcore player in a hardcore world.",
  "The game just alt-f4’d your existence.",
  "You got sent home with a participation trophy made of L’s.",
  "That death had more plot twists than your skill progression.",
  "You just got outclassed by gravity.",
  "Another free highlight for someone else’s montage.",
  "You died with the energy of a disconnected controller.",
  "Cause of death: chronic inability to press the right buttons.",
  "You just got deleted and the recycle bin rejected you.",
  "That was a speedrun to the afterlife of noobs.",
  "You died so pathetically the death message auto-censored itself.",
  "Respawn and pretend this never happened.",
  "You just got cooked by basic game design.",
  "Pure comedy gold. Thanks for the content.",
  "You died like your internet: laggy and unreliable.",
  "The void is full because of players like you.",
  "You just got ratio’d by a single block.",
  "That death was so bad it lowered the server’s average IQ.",
  "You died with zero resistance and maximum cope.",
  "Another one for the hall of shame.",
  "You just got sent to the shadow realm of “maybe next time.”",
  "That was less of a death and more of a skill check you failed.",
  "You died like a loading screen: stuck and useless.",
  "Cause of death: existing while bad.",
  "You just got folded harder than a paper airplane in a storm.",
  "The respawn button is your most used feature.",
  "You died so hard even the backup server felt it.",
  "That death belongs in a “what not to do” video.",
  "You just became a walking (now dead) skill issue.",
  "Pure dogwater. Nothing else needs to be said.",
  "You died with the confidence of someone who’s never touched grass.",
  "The game just force-closed your tab.",
  "You got sent back to the tutorial island of life.",
  "That death was a masterclass in self-sabotage.",
  "You just got outplayed by the concept of dying.",
  "Another noob claimed by the death screen.",
  "You died like your last brain cell: suddenly and permanently.",
  "Cause of death: refusing to improve.",
  "You just got completely and utterly fucking deleted. Sit down.",
  "Madarchod, tu abhi abhi permanently delete ho gaya, jaake soch apni zindagi ke bare mein.",
  "Bhosdike, itni beizzati wali death dekh ke void bhi sharma gaya.",
  "Chutiya, tune apni humiliation ka speedrun complete kar diya.",
  "Betichod, pure server ne teri yeh death dekh li, ab kahan chhupega.",
  "Randi ke bacche, ek aur L history mein register ho gaya.",
  "Madarchod, wapas respawn screen pe chala gaya jahan tera asli ghar hai.",
  "Bhosdiwale, server ki sabse embarrassing death abhi abhi hui.",
  "Chutiye, teri death se teri purani generation ko bhi sharam aa gayi.",
  "Beti chod, pure dogwater death, kuch kehne layak bacha hi nahi.",
  "Teri maa ka bhosda, tu bilkul cook ho gaya, plate mein serve bhi ho gaya.",
  "Madarchod, game ne khud tujhe mid-fight reject kar diya.",
  "Bhosdike, zero dignity ke saath maximum cringe ke saath mara.",
  "Chutiya, yeh death tere pure skill issue ne sponsor ki thi.",
  "Betichod, ek block of dirt ne tujhe ratio de diya.",
  "Randi ke aulad, respawn kar aur dobara itni beizzati mat karwa.",
  "Madarchod, itni bekar death hui ki death message bhi tujhe judge kar raha hai.",
  "Bhosdiwale, jo bhi paas tha usko free kill mil gaya.",
  "Chutiye, bad players ke shadow realm mein chala gaya tu.",
  "Betichod, yeh death nahi thi, public execution thi.",
  "Teri behen ki chut, teri death bilkul teri WiFi jaisi thi – achanak aur bekaar.",
  "Madarchod, skill issue detect hua. Cause of death: pure trash.",
  "Bhosdike, map se bhi jyada fold ho gaya tu.",
  "Chutiya, void ne phone kiya, apna sabse bekar player wapas maang raha hai.",
  "Beti chod, itni bekar death hui ki achievements ne track karna bhi refuse kar diya.",
  "Randi ke bacche, ek aur noob mitti mein mil gaya… mitti bhi disappointed hai.",
  "Madarchod, basic Minecraft mechanics se bhi haar gaya.",
  "Bhosdiwale, yeh death failure ke museum mein rakhne layak hai.",
  "Chutiye, jaise khelta hai waise hi mara – bilkul zero energy se.",
  "Betichod, respawn button ab tera sabse familiar dost ban gaya hai.",
  "Teri maa ka bhosda, bad schematic se bhi jyada hard delete ho gaya.",
  "Madarchod, pure comedy death. Dobara dekhne layak.",
  "Bhosdike, itni cringe death hui ki server lag kar gaya.",
  "Chutiya, kaise nahi khelna chahiye uski masterclass de di tune.",
  "Betichod, kill feed ke liye free content ban gaya.",
  "Randi ke aulad, cause of death: terminal skill issue.",
  "Madarchod, hardcore mein tutorial player jaisi death mari.",
  "Bhosdiwale, game ne teri existence ko force-quit kar diya.",
  "Chutiye, izzat yahin chhod ke spawn pe wapas aa gaya.",
  "Beti chod, itni bekar death ban reason banni chahiye.",
  "Teri behen ki chut, physics ke laws ne tujhe pakad liya.",
  "Madarchod, ek aur noob down. Cycle jaari hai.",
  "Bhosdike, skill se jyada cope ke saath mara.",
  "Chutiya, ladai nahi thi, seedha surrender tha.",
  "Betichod, bad players ke afterlife mein hard-stuck ho gaya.",
  "Randi ke bacche, respawn kar aur soch kaunsi galatiyan yahan tak le aayi.",
  "Madarchod, itni bekar death hui ki mobs bhi has rahe hain.",
  "Bhosdiwale, pure dogshit death. Koi notes nahi.",
  "Chutiye, respect ke scoreboard se erase ho gaya.",
  "Betichod, zero aura maximum embarrassment wali death.",
  "Teri maa ka bhosda, teri inventory jaisi death – khaali aur bekaar.",
  "Madarchod, skill-issue gods ne ek aur qurbani le li.",
  "Bhosdike, bad gameplay ke gulag mein chala gaya.",
  "Chutiya, galat reasons ke liye cinematic death ho gayi.",
  "Beti chod, kabhi na jeetne wale player jaisi confidence ke saath mara.",
  "Randi ke aulad, cause of death: get good karne se inkaar.",
  "Madarchod, failure ke naye dimension mein fold ho gaya.",
  "Bhosdiwale, respawn screen tujhe miss kar raha tha. Welcome back.",
  "Chutiye, itni hard death hui ki chat abhi bhi recover nahi hua.",
  "Betichod, yeh death skill ke bare mein public service announcement thi.",
  "Teri behen ki chut, ab tu cautionary tale ban gaya.",
  "Madarchod, pure trash death. Recommend nahi karunga.",
  "Bhosdike, hardcore duniya mein softcore player jaisi death.",
  "Chutiya, game ne teri tab force-close kar di.",
  "Betichod, L’s ka participation trophy leke ghar bhej diya gaya.",
  "Randi ke bacche, teri skill progression se bhi jyada plot twist wali death.",
  "Madarchod, gravity se bhi haar gaya.",
  "Bhosdiwale, kisi aur ke montage ke liye free highlight ban gaya.",
  "Chutiye, disconnected controller jaisi energy ke saath mara.",
  "Beti chod, cause of death: sahi buttons dabaane ki chronic inability.",
  "Teri maa ka bhosda, delete ho gaya aur recycle bin ne bhi reject kar diya.",
  "Madarchod, noobs ke afterlife ka speedrun complete.",
  "Bhosdike, itni bekar death hui ki death message ne khud ko censor kar liya.",
  "Chutiye, respawn kar aur pretend kar yeh hua hi nahi.",
  "Betichod, basic game design ne tujhe paka liya.",
  "Randi ke aulad, pure comedy gold. Content ke liye shukriya.",
  "Madarchod, teri internet jaisi death – laggy aur unreliable.",
  "Bhosdiwale, void tere jaise players se bhar gaya hai.",
  "Chutiya, ek single block ne tujhe ratio de diya.",
  "Betichod, itni bekar death hui ki server ka average IQ gir gaya.",
  "Teri behen ki chut, zero resistance maximum cope ke saath mara.",
  "Madarchod, hall of shame mein ek aur naam add ho gaya.",
  "Bhosdike, “maybe next time” ke shadow realm mein chala gaya.",
  "Chutiya, death nahi thi, failed skill check thi.",
  "Beti chod, loading screen jaisi death – atki hui aur bekaar.",
  "Randi ke bacche, cause of death: bad hote hue exist karna.",
  "Madarchod, toofan mein paper airplane se bhi jyada fold ho gaya.",
  "Bhosdiwale, respawn button tera sabse jyada use hone wala feature hai.",
  "Chutiye, itni hard death hui ki backup server ne bhi mehsoos kiya.",
  "Betichod, “kya nahi karna chahiye” wali video ke liye perfect death.",
  "Teri maa ka bhosda, ab tu walking (ab dead) skill issue ban gaya.",
  "Madarchod, pure dogwater. Aur kuch kehne ki zaroorat nahi.",
  "Bhosdike, kabhi grass touch na karne wale player jaisi confidence ke saath mara.",
  "Chutiya, game ne teri tab force-close kar di.",
  "Betichod, life ke tutorial island pe wapas bhej diya gaya.",
  "Randi ke aulad, self-sabotage ki masterclass de di.",
  "Madarchod, marne ke concept se bhi haar gaya.",
  "Bhosdiwale, death screen ne ek aur noob claim kar liya.",
  "Chutiye, apne last brain cell jaisi death – achanak aur permanent.",
  "Beti chod, cause of death: improve karne se inkaar.",
  "Teri maa ka bhosda, bilkul completely aur utterly delete ho gaya. Ab baith ja."
];

const allRandomBanterMessages = [...randomBanterMessages, ...customRandomMessages];

const baseDeathObserverRoasts = [
  "Skill issue bhai 💀",
  "F in the chat! Yamraj bula rahe the isko! 😂",
  "Aise marte hain kya log? Zombie ne ek thappad me sulah diya! 🧟",
  "Abe gaya kaam se! Loot mai utha lu kya iski? 🗿",
  "Rest in peace... agle janam me thoda dhang se khelna!"
];
const allDeathObserverRoasts = [...baseDeathObserverRoasts, ...customDeathMessages];

// Simple HTTP server for hosting platforms (Render, Koyeb, etc.)
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    status: 'online',
    bot: config.username,
    server: `${config.host}:${config.port}`,
    ai: 'RamLaal-GPT v2.0 Active'
  }));
});

server.listen(config.httpPort, () => {
  console.log(`[Web Server] Listening on port ${config.httpPort}`);
});

let bot = null;
let movementInterval = null;
let combatInterval = null;
let reconnectTimeout = null;
let randomChatTimeout = null;
let isTryingToSleep = false;
let isEating = false;
let lastSleepAttempt = 0;
let lastHurtTime = 0;
let lastProximityCheck = 0;
let lastBattleCry = 0;
let lastCreeperWarn = 0;
let lastArmorEquipChat = 0;
let lastEatChat = 0;
let proximityCooldowns = {};

// Base Anchor - RamLaal stays near base only (never leaves base perimeter)
let baseAnchor = null;
const BASE_PATROL_RADIUS = 7; // Max distance in blocks from base center

function createBot() {
  cleanupTimers();

  console.log(`[Bot] Connecting to ${config.host}:${config.port} as ${config.username}...`);

  const botOptions = {
    host: config.host,
    port: config.port,
    username: config.username,
    auth: config.auth
  };

  if (config.version) {
    botOptions.version = config.version;
  }

  bot = mineflayer.createBot(botOptions);

  bot.on('login', () => {
    console.log(`[Bot] Logged into ${config.host}:${config.port} successfully!`);
  });

  // Auto-detect when RamLaal is teleported (e.g. /tp) and lock new base anchor
  bot.on('forcedMove', () => {
    if (bot && bot.entity) {
      baseAnchor = bot.entity.position.clone();
      console.log(`[Base Guard] Teleport detected via forcedMove! Base anchor reset to: ${baseAnchor.floored()}`);
    }
  });

  bot.on('spawn', () => {
    console.log('[Bot] Spawned in the world. Initializing AI perception core...');
    startMovementLoop();
    scheduleRandomChat();
    try {
      bot.chat("RamLaal-GPT v2.0 AI Core Loaded! Namaste sabhi ko 🤖🙏");
    } catch (_) {}
  });

  // Bed and Sleep Handlers
  bot.on('time', () => {
    if (!bot || bot.isSleeping) return;

    const now = Date.now();
    if (now - lastSleepAttempt < 10000) return; // Check every 10 seconds

    const isNight = bot.time && (bot.time.timeOfDay >= 12541 && bot.time.timeOfDay <= 23458);
    const isThunder = bot.isRaining && (bot.thunderState > 0);

    if (isNight || isThunder) {
      const bed = findNearbyBed();
      if (bed) {
        lastSleepAttempt = now;
        goToSleep(true); // Silent automatic attempt
      }
    }
  });

  bot.on('wake', () => {
    console.log('[Bed] RamLaal woke up! Resuming movement...');
    try {
      bot.chat(getRandom(wakeMessages));
    } catch (_) {}
    startMovementLoop();
  });

  // Physical Combat Reaction (When RamLaal gets attacked)
  bot.on('entityHurt', (entity) => {
    if (!bot || !entity) return;
    if (entity === bot.entity) {
      const now = Date.now();
      if (now - lastHurtTime > 4000) { // 4 second cooldown
        lastHurtTime = now;
        try {
          bot.swingArm('right');
          bot.chat(getRandom(hurtMessages));
        } catch (_) {}
      }
    }
  });

  // Observer AI: Roasts players when someone dies near him
  bot.on('entityDead', (entity) => {
    if (!bot || !entity || entity === bot.entity) return;
    if (entity.type === 'player' && entity.username) {
      try {
        bot.chat(getRandom(allDeathObserverRoasts));
      } catch (_) {}
    }
  });

  // Weather Awareness
  bot.on('rain', () => {
    if (!bot) return;
    try {
      if (bot.isRaining) {
        bot.chat("Arre baarish shuru ho gayi! Mummy pakode bana do 🌧️☕");
      } else {
        bot.chat("Baarish ruk gayi, chalo dhoop sekte hain ab ☀️");
      }
    } catch (_) {}
  });

  // In-game Chat Handling with Interactive AI
  bot.on('chat', (username, message) => {
    if (!bot || username === bot.username) return;
    handlePlayerChat(username, message);
  });

  bot.on('death', () => {
    console.log('[Bot] Bot died. Respawning...');
    stopMovementLoop();
    try {
      bot.chat(getRandom(deathMessages));
    } catch (_) {}
    setTimeout(() => {
      if (bot) bot.respawn();
    }, 2000);
  });

  bot.on('kicked', (reason) => {
    console.warn(`[Bot] Kicked: ${JSON.stringify(reason)}`);
  });

  bot.on('error', (err) => {
    console.error(`[Bot Error] ${err.message}`);
  });

  bot.on('end', () => {
    console.log(`[Bot] Disconnected from server. Reconnecting in ${config.reconnectDelay / 1000}s...`);
    cleanupTimers();
    scheduleReconnect();
  });
}

function lookAtPlayer(username) {
  if (!bot || !bot.players[username] || !bot.players[username].entity) return;
  try {
    const playerPos = bot.players[username].entity.position.offset(0, 1.6, 0);
    bot.lookAt(playerPos);
  } catch (_) {}
}

async function doJump() {
  if (!bot || bot.isSleeping) return;
  bot.setControlState('jump', true);
  await sleep(350);
  if (bot) bot.setControlState('jump', false);
}

async function doTwerk() {
  if (!bot || bot.isSleeping) return;
  for (let i = 0; i < 5; i++) {
    bot.setControlState('sneak', true);
    await sleep(200);
    if (!bot) return;
    bot.setControlState('sneak', false);
    await sleep(200);
  }
}

async function doSpin() {
  if (!bot || !bot.entity || bot.isSleeping) return;
  const originalYaw = bot.entity.yaw;
  for (let i = 0; i < 8; i++) {
    bot.look(originalYaw + (i * Math.PI / 4), bot.entity.pitch, true);
    await sleep(80);
    if (!bot) return;
  }
}

async function doPunch() {
  if (!bot || bot.isSleeping) return;
  for (let i = 0; i < 4; i++) {
    bot.swingArm('right');
    await sleep(250);
  }
}

// Human-like animation: Waving friendly arm
async function waveArm() {
  if (!bot || bot.isSleeping) return;
  for (let i = 0; i < 3; i++) {
    bot.swingArm('right');
    await sleep(200);
  }
}

// Human-like animation: Nodding head yes
async function nodHead() {
  if (!bot || !bot.entity || bot.isSleeping) return;
  const originalPitch = bot.entity.pitch;
  try {
    bot.look(bot.entity.yaw, originalPitch + 0.4, true);
    await sleep(150);
    bot.look(bot.entity.yaw, originalPitch - 0.4, true);
    await sleep(150);
    bot.look(bot.entity.yaw, originalPitch, true);
  } catch (_) {}
}

// Human-like animation: Universal Minecraft friendly crouch-greeting
async function friendlyCrouchGreeting() {
  if (!bot || bot.isSleeping) return;
  for (let i = 0; i < 3; i++) {
    bot.setControlState('sneak', true);
    await sleep(180);
    if (!bot) return;
    bot.setControlState('sneak', false);
    await sleep(180);
  }
}


// ==========================================
// 🗣️ INTERACTIVE AI CHAT & COMMAND PROCESSOR
// ==========================================
function handlePlayerChat(username, message) {
  const text = message.trim().toLowerCase();

  // Set Base Anchor Command (!setbase, !anchor, yahan raho)
  if (text === '!setbase' || text === '!anchor' || text.includes('yahan raho') || text.includes('ye base hai') || text.includes('set base')) {
    lookAtPlayer(username);
    if (bot && bot.entity) {
      baseAnchor = bot.entity.position.clone();
      waveArm();
      bot.chat(`Theek hai ${username} bhai! Ye mera naya base spot hai. Ab mai yahin ghoomunga aur base ki shaan banunga 🏡📍✨`);
    }
    return;
  }

  // Adorable: Hug command
  if (text === '!hug' || text.includes('hug') || text.includes('gale mil') || text.includes('pyaar') || text.includes('love u') || text.includes('love you')) {
    lookAtPlayer(username);
    friendlyCrouchGreeting();
    waveArm();
    const hugReplies = [
      `Awww! Badi wali warm virtual hug for you, ${username}! 🤗❤️ RamLaal loves you!`,
      `*Big warm hug* 🤗✨ Tum sabse pyare player ho ${username}!`,
      `Arey aao gale lago ${username} bhai! Dil khush kar diya tumne! ❤️🥰`
    ];
    bot.chat(getRandom(hugReplies));
    return;
  }

  // Adorable: Headpat command
  if (text === '!pat' || text.includes('pat') || text.includes('headpat') || text.includes('pucho')) {
    lookAtPlayer(username);
    nodHead();
    const patReplies = [
      `Hehe tickles! *happy purring sounds* Thank you for the headpat, ${username}! 🥰✨`,
      `Awww thank you ${username}! RamLaal feels so loved right now! 🐾💖`,
      `Yay headpats! *wags imaginary tail* Tum kitne acche ho! 🥰`
    ];
    bot.chat(getRandom(patReplies));
    return;
  }

  // Adorable: Flower gift command
  if (text === '!flower' || text.includes('flower') || text.includes('phool') || text.includes('gift')) {
    lookAtPlayer(username);
    waveArm();
    const flowerReplies = [
      `Ye lo ${username}! Ek pyara sa virtual phool tumhare liye 🌸🌼 Khush raho hamesha!`,
      `Tumhare liye ek sundar red rose 🌹 Kyunki tum base ke sabse acche dost ho!`,
      `Special flower delivery for ${username}! 🌻✨ Enjoy karo!`
    ];
    bot.chat(getRandom(flowerReplies));
    return;
  }

  // Adorable: Singing command
  if (text === '!sing' || text.includes('sing') || text.includes('gaana') || text.includes('song')) {
    lookAtPlayer(username);
    doJump();
    const songs = [
      `Lala lala lori, Minecraft ki katori! Steve chala mine me, RamLaal base ki shaan hai! 🎶🎤`,
      `Chhoti si aasha, dher saare diamonds! RamLaal gaata hai sabke liye pyaar se! 🎵✨`,
      `Twinkle twinkle little star, tum sab log ho superstar! 🌟🎶`
    ];
    bot.chat(getRandom(songs));
    return;
  }

  // Adorable: Sweet compliments
  if (text === '!compliment' || text.includes('tareef')) {
    lookAtPlayer(username);
    nodHead();
    const sweetLines = [
      `Tumhara character skin kitna cute lag raha hai aaj ${username}! Sachhi! ✨`,
      `${username}, tum is pure server ke sabse pyare aur mehnati player ho! 💖`,
      `Agar Minecraft me 'Best Player Award' hota toh pakka ${username} ko milta! 🏆🥰`
    ];
    bot.chat(getRandom(sweetLines));
    return;
  }

  // 1. Sleep & Wake Commands
  if (text === '!sleep' || text === 'sleep' || text === 'soja' || text === 'soja ramlaal' || text === 'so ja') {
    lookAtPlayer(username);
    goToSleep(false);
    return;
  }

  if (text === '!wake' || text === 'wake' || text === 'uth ja' || text === 'uthja' || text === 'uth') {
    lookAtPlayer(username);
    if (bot.isSleeping) {
      bot.wake().catch(() => {});
    } else {
      bot.chat(`Abe aalsi ${username}, mai to kabse jaag raha hu!`);
    }
    return;
  }

  // 2. Twerk / Crouch Action
  if (text === '!twerk' || text.includes('twerk') || text.includes('mujra') || text.includes('crouch')) {
    lookAtPlayer(username);
    bot.chat(`RamLaal Twerk Protocol Activated! 💃🕺`);
    doTwerk();
    return;
  }

  // 3. Jump / Dance
  if (text.includes('jump') || text.includes('kood') || text.includes('dance') || text.includes('naach')) {
    lookAtPlayer(username);
    doJump();
    const jumpReplies = [
      `Abe mai RamLaal hu, Nora Fatehi nahi jo mujra karu! Par ek jump maar leta hu 🕺`,
      `Ye le ${username} bhai jump! Khush? Ab kaam dhandha karne do 🗿`,
      `DJ wale babu mera gaana chala do! 🕺✨`,
      `Jump to maar diya, ab 1 diamond fees nikaal ${username}!`
    ];
    bot.chat(getRandom(jumpReplies));
    return;
  }

  // 4. Punch / Fight / Boxing
  if (text === '!fight' || text.includes('fight') || text.includes('punch') || text.includes('maar') || text.includes('lad')) {
    lookAtPlayer(username);
    doPunch();
    bot.chat(`Aaja ${username} maidaan me! RamLaal boxing champion of Aternos hai! 🥊💥`);
    return;
  }

  // 5. Spin / Ghoom
  if (text === '!spin' || text.includes('spin') || text.includes('ghoom') || text.includes('beyblade')) {
    lookAtPlayer(username);
    bot.chat(`Beyblade mode ON! 🌪️`);
    doSpin();
    return;
  }

  // 6. Shayari Generator
  if (text === '!shayari' || text.includes('shayari') || text.includes('poem') || text.includes('kavita')) {
    lookAtPlayer(username);
    bot.chat(getRandom(shayaris));
    return;
  }

  // 7. Fortune / Kismat Predictor
  if (text === '!fortune' || text.includes('kismat') || text.includes('future') || text.includes('bhavishya')) {
    lookAtPlayer(username);
    bot.chat(getRandom(fortunes));
    return;
  }

  // 8. IQ Scanner (Fake AI calculation)
  if (text === '!iq' || text.includes('iq') || text.includes('dimaag')) {
    lookAtPlayer(username);
    const fakeIQ = Math.floor(Math.random() * 140) + 10;
    if (fakeIQ < 40) {
      bot.chat(`🧠 [AI Brain Scan]: ${username} ka IQ = ${fakeIQ}. Arey baap re! Dirt block me bhi zyada dimaag hota hai 💀`);
    } else if (fakeIQ < 90) {
      bot.chat(`🧠 [AI Brain Scan]: ${username} ka IQ = ${fakeIQ}. Average noob spotted! Thoda almond khaya karo.`);
    } else {
      bot.chat(`🧠 [AI Brain Scan]: ${username} ka IQ = ${fakeIQ}. Wah bhai, Einstein ke baad tumhara hi number hai! 🗿✨`);
    }
    return;
  }

  // 9. Coin Toss
  if (text === '!toss' || text === '!coin' || text.includes('toss') || text.includes('coin')) {
    const outcome = Math.random() < 0.5 ? 'HEADS (Sir)' : 'TAILS (Poonch)';
    bot.chat(`🪙 Coin flipped! Result is: ${outcome}`);
    return;
  }

  // 10. AI Math Calculator (!calc 5+5)
  if (text.startsWith('!calc ') || text.startsWith('calc ')) {
    const expr = text.replace('!calc ', '').replace('calc ', '').trim();
    try {
      // Safe math evaluation with sanitized characters
      if (/^[0-9+\-*/().\s]+$/.test(expr)) {
        const result = Function(`'use strict'; return (${expr})`)();
        bot.chat(`🧠 [AI Computation]: ${expr} = ${result}. Itna aasaan sawal nursery ka baccha bhi kar leta! 🤖`);
      } else {
        bot.chat("Abe sahi maths likh! NASA ke rocket formula mat daal yahan.");
      }
    } catch (_) {
      bot.chat("Calculation error! Tumhare sawal ne mera AI brain hang kar diya.");
    }
    return;
  }

  // 11. Roast Generator (!roast or roast me)
  if (text.startsWith('!roast') || text.includes('roast')) {
    lookAtPlayer(username);
    let target = username;
    const parts = text.split(' ');
    if (parts.length > 1 && parts[1].length > 1 && parts[1] !== 'me') {
      target = parts[1];
    }
    const roasts = [
      `${target} ko dekh ke toh Skeleton bhi has ke apna bow fenk deta hai! 💀`,
      `${target} ka gameplay dekh ke lagta hai keypad phone pe Minecraft khel raha hai 😂`,
      `Scientists are still researching how ${target} survived this long without a brain in Minecraft.`,
      `${target} wahi banda hai jo lava ke bagal me lakdi ka ghar banata hai 🪵🔥`,
      `${target} se accha PvP toh Minecraft ka villager 'Hrrrm' bol ke kar leta hai! 🤡`
    ];
    bot.chat(getRandom(roasts));
    return;
  }

  // 12. Insults / Gaali / Noob / Roasts
  if (text.includes('noob') || text.includes('bot') || text.includes('chutiya') || text.includes('pagal') ||
      text.includes('bhadwe') || text.includes('gadhe') || text.includes('stupid') || text.includes('idiot') ||
      text.includes('bkl') || text.includes('bsdk') || text.includes('lmao') || text.includes('chup') || text.includes('shut up')) {
    lookAtPlayer(username);
    const roastReplies = [
      `Abe ${username}, khud to dirt ke ghar me rehta hai aur mujhe gyaan de raha hai! 🗿`,
      `Zuban sambhal ke ${username}, varna Aternos band karke bhaag jaunga, rote rehna fir! 😂`,
      `Mujhe bot bol raha hai? Kam se kam mai Creeper ko dekh ke bhagta nahi teri tarah! 💀`,
      `Abe ${username}, tujhse accha PvP toh Minecraft ka zombie kar leta hai! 🧟`,
      `Dekho kaun bol raha hai, jo kal ped se gir ke mar gaya tha! 🤡`,
      `Arey ${username} bhai, itna gussa kyu? Thanda paani piyo aur mining karo!`,
      `Abe chal nikal, tere jaise 50 dekhe hain maine!`
    ];
    bot.chat(getRandom(roastReplies));
    return;
  }

  // 13. Asking for items / Diamonds / Khana
  if (text.includes('diamond') || text.includes('iron') || text.includes('khana') || text.includes('food') ||
      text.includes('roti') || text.includes('paisa') || text.includes('give') || text.includes('de na') || text.includes('loot')) {
    lookAtPlayer(username);
    const beggarReplies = [
      `Abe ${username}, mai khud nanga ghoom raha hu, tujhe kahan se diamond du?! 😭`,
      `Mere paas sirf aashirwaad hai beta, diamond chahiye toh khud khodo! ⛏️`,
      `Mai koi Ration card ki dukaan thodi hu jo khana baantu! Khud kheti karo.`,
      `Ghar se ameer, dil se fakeer hu mai bhai. Kuch nahi hai mere paas 🥲`,
      `Pehle mujhe netherite armor pehna, fir maangna diamond!`
    ];
    bot.chat(getRandom(beggarReplies));
    return;
  }

  // 14. Creator / Who made you
  if (text.includes('who made') || text.includes('tera baap') || text.includes('creator') || text.includes('developer') || text.includes('kisne banaya')) {
    lookAtPlayer(username);
    bot.chat(`Mujhe krajtilak ne banaya hai! The supreme creator and coding master of this server 👑💻`);
    return;
  }

  // 15. Girlfriend / Crush / Love
  if (text.includes('girlfriend') || text.includes('crush') || text.includes('shadi') || text.includes('gf')) {
    lookAtPlayer(username);
    bot.chat(`Alex meri crush thi par wo Steve ke saath bhaag gayi... dard, dukh, peeda 💔😭`);
    return;
  }

  // 16. Greetings
  if (text.includes('hi') || text.includes('hello') || text.includes('hey') || text.includes('sup') ||
      text.includes('kaisa hai') || text.includes('kaise ho') || text.includes('kya haal') || text.includes('wassup')) {
    lookAtPlayer(username);
    const greetReplies = [
      `Arre ${username} bhai! Haal chaal mast, bas 24 ghante chalte chalte ghutne ghis gaye 💀`,
      `Hello ${username}! Khana khake aaya ya bas RamLaal ka dimag khane aaya hai?`,
      `Salam-namaste ${username} babu! Kaho kya taaza khabar hai?`,
      `Wassup ${username}! Server pe aate hi RamLaal ki yaad aa gayi? 🗿`,
      `Arre aao aao ${username}, tumhare bina server bohot sunsaan lag raha tha!`
    ];
    bot.chat(getRandom(greetReplies));
    return;
  }

  // 17. Compliments & Praise
  if (text.includes('pro') || text.includes('op') || text.includes('legend') || text.includes('goat') ||
      text.includes('king') || text.includes('love') || text.includes('bhai hai tu') || text.includes('nice')) {
    lookAtPlayer(username);
    doJump();
    const praiseReplies = [
      `Shukriya shukriya! RamLaal is the real hero of this server 🗿✨`,
      `Makkhan lagana band kar ${username}, fir bhi diamond nahi dunga! 😂`,
      `Arey bas kar pagle ${username}, itni tareef sunke meri aankho me aansu aa gaye ❤️`,
      `Pata hai mujhe mai OP hu, aage se salute thok ke baat karna!`
    ];
    bot.chat(getRandom(praiseReplies));
    return;
  }

  // 18. Goodbyes
  if (text.includes('bye') || text.includes('tata') || text.includes('goodbye') || text.includes('ja raha hu') || text.includes('offline')) {
    const byeReplies = [
      `Jao jao ${username}, vaise bhi tumhare rehne se konsa Ender Dragon mar gaya tha! 👋`,
      `Bye ${username}! Server band mat hone dena varna bhoot le jayega tujhe!`,
      `Alvida dost! Sapno me aake tumhe Creeper se katwaunga 💥`
    ];
    bot.chat(getRandom(byeReplies));
    return;
  }

  // 19. General Name Mention (RamLaal / Ramlal)
  if (text.includes('ramlaal') || text.includes('ramlal')) {
    lookAtPlayer(username);
    const nameReplies = [
      `Haan bhai ${username}, RamLaal hazir hai! Saaf-saaf bolo kya chahiye?`,
      `RamLaal ko pukara aur hum chale aaye 🗿`,
      `Abe ${username}, mera naam japne se swarg nahi milega!`,
      `Bolo ${username} babu, kisne sataya tumhe?`,
      `Haa bhai bol, sun raha hu mai!`
    ];
    bot.chat(getRandom(nameReplies));
  }
}

function findNearbyBed() {
  if (!bot) return null;
  return bot.findBlock({
    matching: block => bot.isABed(block),
    maxDistance: 4
  });
}

async function goToSleep(silent = false) {
  if (!bot || bot.isSleeping || isTryingToSleep) return;

  const isNight = bot.time && (bot.time.timeOfDay >= 12541 && bot.time.timeOfDay <= 23458);
  const isThunder = bot.isRaining && (bot.thunderState > 0);

  if (!isNight && !isThunder) {
    if (!silent) bot.chat(getRandom(notNightMessages));
    return;
  }

  const bed = findNearbyBed();
  if (!bed) {
    if (!silent) bot.chat(getRandom(noBedMessages));
    console.log('[Bed] No bed found within 4 blocks.');
    return;
  }

  try {
    isTryingToSleep = true;
    stopMovementLoop();
    console.log('[Bed] Attempting to sleep in bed...');
    await bot.sleep(bed);
    console.log('[Bed] RamLaal is now sleeping in bed!');
    bot.chat(getRandom(sleepMessages));
  } catch (err) {
    console.warn(`[Bed Error] ${err.message}`);
    if (!silent) bot.chat(`Abe so nahi pa raha hu: ${err.message}`);
    if (!bot.isSleeping) {
      startMovementLoop();
    }
  } finally {
    isTryingToSleep = false;
  }
}

// Track player distances to trigger adorable "Welcome Home" reactions
const playerLastDistance = {};

function checkPlayerProximity() {
  if (!bot || !bot.entity || bot.isSleeping) return;
  const now = Date.now();
  if (now - lastProximityCheck < 3000) return; // check every 3 seconds
  lastProximityCheck = now;

  for (const player of Object.values(bot.players)) {
    if (!player || !player.entity || player.username === bot.username) continue;
    const dist = bot.entity.position.distanceTo(player.entity.position);
    const prevDist = playerLastDistance[player.username] || dist;
    playerLastDistance[player.username] = dist;

    // ADORABLE: Welcome Home Reaction (Player returns from mining/exploring to base)
    if (prevDist > 14 && dist <= 5.5) {
      const lastWelcome = proximityCooldowns['welcome_' + player.username] || 0;
      if (now - lastWelcome > 90000) { // 90s cooldown per player
        proximityCooldowns['welcome_' + player.username] = now;
        lookAtPlayer(player.username);
        friendlyCrouchGreeting();
        waveArm();
        const welcomeLines = [
          `Yay! ${player.username} wapas aa gaye! Maine base ka bohot dhyan rakha! Welcome home! 🥰✨`,
          `Arey dekho kaun aaya! Welcome back ${player.username}! Tumhare bina base kitna soona tha! 🏡💖`,
          `Hamara hero wapas aa gaya! Welcome back ${player.username}! Kaisi rahi mining? ⛏️❤️`
        ];
        try { bot.chat(getRandom(welcomeLines)); } catch (_) {}
        continue;
      }
    }

    // Friendly greeting when standing close (crouch & wave)
    if (dist < 2.2) {
      const lastSpoken = proximityCooldowns[player.username] || 0;
      if (now - lastSpoken > 40000) { // 40s cooldown per player
        proximityCooldowns[player.username] = now;
        lookAtPlayer(player.username);
        friendlyCrouchGreeting();
        const cuteStareLines = [
          `Hello ${player.username}! Kaise ho aap? RamLaal is happy to see you! 🥰✨`,
          `Arey ${player.username}! Itne paas aaye ho toh ek high-five de do! ✋💖`,
          `Kya haal chaal ${player.username}? Dekho mai base ka mast guard ban ke khada hu! 🌸`
        ];
        try { bot.chat(getRandom(cuteStareLines)); } catch (_) {}
      }
    }
  }
}


// ==========================================
// 🛡️ SMART BASE GUARD & SURVIVAL AI
// ==========================================

const HOSTILE_MOBS = new Set([
  'zombie', 'skeleton', 'spider', 'cave_spider', 'creeper',
  'drowned', 'husk', 'phantom', 'witch', 'slime', 'magma_cube',
  'pillager', 'vindicator', 'ravager'
]);

const FOOD_NAMES = new Set([
  'bread', 'cooked_beef', 'cooked_porkchop', 'cooked_mutton',
  'cooked_chicken', 'baked_potato', 'apple', 'golden_apple',
  'cookie', 'cooked_salmon', 'cooked_cod', 'carrot'
]);

// Auto-equip best weapon (sword or axe)
async function equipBestWeapon() {
  if (!bot || !bot.inventory) return;
  const weapon = bot.inventory.items().find(i => i.name.endsWith('_sword') || i.name.endsWith('_axe'));
  if (weapon) {
    try {
      await bot.equip(weapon, 'hand');
    } catch (_) {}
  }
}

// Auto-equip armor pieces and shield if available in inventory
async function autoEquipArmor() {
  if (!bot || !bot.inventory || bot.isSleeping) return;
  const items = bot.inventory.items();

  const helmet = items.find(i => i.name.endsWith('_helmet'));
  const chest = items.find(i => i.name.endsWith('_chestplate'));
  const legs = items.find(i => i.name.endsWith('_leggings'));
  const boots = items.find(i => i.name.endsWith('_boots'));
  const shield = items.find(i => i.name === 'shield');

  let equippedSomething = false;
  try {
    if (helmet) { await bot.equip(helmet, 'head'); equippedSomething = true; }
    if (chest) { await bot.equip(chest, 'torso'); equippedSomething = true; }
    if (legs) { await bot.equip(legs, 'legs'); equippedSomething = true; }
    if (boots) { await bot.equip(boots, 'feet'); equippedSomething = true; }
    if (shield) { await bot.equip(shield, 'off-hand'); equippedSomething = true; }
  } catch (_) {}

  if (equippedSomething) {
    const now = Date.now();
    if (now - lastArmorEquipChat > 45000) {
      lastArmorEquipChat = now;
      const armorLines = [
        "Armor pehan liya! Ab RamLaal poora base warrior ban gaya 🛡️✨",
        "Khatarnak gear mil gaya! Ab koi mob base me ghus ke dikhaye 🗿⚔️",
        "Iron Man bana diya tumne mujhe! Shandaar armor hai!"
      ];
      try { bot.chat(getRandom(armorLines)); } catch (_) {}
    }
  }
}

// Auto-eat food when health is low
async function autoEatFood() {
  if (!bot || !bot.inventory || isEating || bot.isSleeping) return;
  if (bot.health >= 16) return; // Only eat when hurt (under 8 hearts)

  const food = bot.inventory.items().find(i => FOOD_NAMES.has(i.name));
  if (!food) return;

  try {
    isEating = true;
    await bot.equip(food, 'hand');
    const now = Date.now();
    if (now - lastEatChat > 30000) {
      lastEatChat = now;
      bot.chat("Thoda khaana kha ke health badha raha hu... 🍖");
    }
    await bot.consume();
  } catch (_) {}
  finally {
    isEating = false;
    equipBestWeapon();
  }
}

// Combat loop: detects nearby mobs, attacks them, retreats from creepers
async function checkCombatAndMobs() {
  if (!bot || !bot.entity || bot.isSleeping || isEating) return;

  // Find nearest hostile mob within 5.5 blocks
  let nearestHostile = null;
  let nearestDist = 5.5;

  for (const entity of Object.values(bot.entities)) {
    if (!entity || entity === bot.entity) continue;
    if (HOSTILE_MOBS.has(entity.name)) {
      const dist = bot.entity.position.distanceTo(entity.position);
      if (dist < nearestDist) {
        nearestDist = dist;
        nearestHostile = entity;
      }
    }
  }

  if (!nearestHostile) return;

  const now = Date.now();

  // 1. CREEPER TACTICAL RETREAT (Don't let base blow up!)
  if (nearestHostile.name === 'creeper') {
    if (now - lastCreeperWarn > 8000) {
      lastCreeperWarn = now;
      bot.chat("Abe Creeper phootne wala hai! Piche hato sab! 💥🏃");
    }
    // Run backward / away from creeper
    const dx = nearestHostile.position.x - bot.entity.position.x;
    const dz = nearestHostile.position.z - bot.entity.position.z;
    const yawAway = Math.atan2(dx, dz); // away direction
    bot.look(yawAway, 0, true);
    bot.setControlState('forward', true);
    bot.setControlState('sprint', true);
    setTimeout(() => {
      if (bot) {
        bot.setControlState('forward', false);
        bot.setControlState('sprint', false);
      }
    }, 1200);
    return;
  }

  // 2. ATTACK HOSTILE MOB (Zombie, Skeleton, Spider, etc.)
  if (nearestDist <= 4.0) {
    await equipBestWeapon();
    bot.lookAt(nearestHostile.position.offset(0, nearestHostile.height * 0.8, 0));
    bot.attack(nearestHostile);
    bot.swingArm('right');

    if (now - lastBattleCry > 7000) {
      lastBattleCry = now;
      const battleCries = [
        `Abe ${nearestHostile.name} teri aisi taisi! Base me kyu aaya?! ⚔️`,
        `Mar saale ${nearestHostile.name}! RamLaal ke ilaake me aane ki himmat kaise hui! 🥊`,
        `Base guard RamLaal on duty! Ek thappad me dher kar dunga! 🗿💥`
      ];
      try { bot.chat(getRandom(battleCries)); } catch (_) {}
    }
  }
}


// Smart forward movement with automatic wall/stuck detection and evasion
async function smartStepForward(durationMs = 700) {
  if (!bot || !bot.entity || bot.isSleeping) return;

  const startPos = bot.entity.position.clone();
  bot.setControlState('forward', true);
  await sleep(durationMs);
  if (!bot) return;
  bot.setControlState('forward', false);

  const movedDist = startPos.distanceTo(bot.entity.position);

  // If bot moved less than 0.15 blocks in durationMs, he is stuck against a wall or obstacle!
  if (movedDist < 0.15) {
    // 1. Try a small hop (in case it's a 1-block elevation or slab)
    bot.setControlState('jump', true);
    bot.setControlState('forward', true);
    await sleep(350);
    if (!bot) return;
    bot.setControlState('jump', false);
    bot.setControlState('forward', false);

    // If still stuck against a solid wall
    if (startPos.distanceTo(bot.entity.position) < 0.25) {
      // Step backward away from the wall
      bot.setControlState('back', true);
      await sleep(400);
      if (!bot) return;
      bot.setControlState('back', false);

      // Turn 90 to 180 degrees away from the wall
      const turnAngle = (Math.PI * 0.5) + (Math.random() * Math.PI * 0.5);
      bot.look(bot.entity.yaw + turnAngle, 0, true);
    }
  }
}

function startMovementLoop() {
  stopMovementLoop();

  // Set initial base anchor if not set
  if (!baseAnchor && bot && bot.entity) {
    baseAnchor = bot.entity.position.clone();
    console.log(`[Base Guard] Base anchor locked at: ${baseAnchor.floored()}`);
  }

  // Fast Combat & Self-Defense Loop (Every 350ms)
  combatInterval = setInterval(() => {
    try {
      checkCombatAndMobs();
    } catch (_) {}
  }, 350);

  // Natural Base Patrol & Guard AI (Every 4.5 seconds)
  movementInterval = setInterval(async () => {
    if (!bot || !bot.entity || bot.isSleeping || isEating) return;

    try {
      // 1. Check health and eat if needed
      await autoEatFood();

      // 2. Check and equip any gear
      await autoEquipArmor();

      // 3. Check player proximity
      checkPlayerProximity();

      // 4. Update base anchor if near bed
      const bed = findNearbyBed();
      if (bed && !baseAnchor) {
        baseAnchor = bed.position.clone();
      }

      if (!baseAnchor) {
        baseAnchor = bot.entity.position.clone();
      }

      const distFromBase = bot.entity.position.distanceTo(baseAnchor);

      // 1. If RamLaal was teleported or spawned far away (> 15 blocks), update anchor to current spot!
      if (distFromBase > 15) {
        baseAnchor = bot.entity.position.clone();
        console.log(`[Base Guard] Position shifted > 15 blocks. Re-anchored to current location: ${baseAnchor.floored()}`);
      }

      // 2. If drifted past patrol radius (5-7 blocks), gently face towards base center
      if (distFromBase > BASE_PATROL_RADIUS) {
        const dx = baseAnchor.x - bot.entity.position.x;
        const dz = baseAnchor.z - bot.entity.position.z;
        const yawTowardsBase = Math.atan2(-dx, -dz);
        bot.look(yawTowardsBase, 0, true);
        await smartStepForward(700);
        return;
      }

      // 3. Natural gentle living base patrol (takes short natural steps with collision avoidance)
      const actionRoll = Math.random();

      if (actionRoll < 0.35) {
        // Take a small gentle step (1-2 blocks) in an open direction
        const randomAngle = (Math.random() - 0.5) * Math.PI * 0.8;
        bot.look(bot.entity.yaw + randomAngle, (Math.random() - 0.5) * 0.15, true);
        await smartStepForward(600);
      } else if (actionRoll < 0.65) {
        // Natural look-around (horizon, sky, surroundings)
        const yaw = (Math.random() - 0.5) * Math.PI * 0.7;
        const pitch = (Math.random() - 0.5) * 0.3;
        bot.look(bot.entity.yaw + yaw, pitch, true);
      } else if (actionRoll < 0.85) {
        // Look towards nearest player if nearby
        const players = Object.values(bot.players).filter(p => p && p.entity && p.username !== bot.username);
        if (players.length > 0) {
          const nearestPlayer = players[0];
          lookAtPlayer(nearestPlayer.username);
        }
      } else {
        // Peaceful idle pause
        await sleep(500);
      }
    } catch (err) {
      console.error('[Base Guard Error]', err);
    }
  }, 4500);
}

function stopMovementLoop() {
  if (movementInterval) {
    clearInterval(movementInterval);
    movementInterval = null;
  }
  if (combatInterval) {
    clearInterval(combatInterval);
    combatInterval = null;
  }
  if (bot) {
    try {
      bot.clearControlStates();
    } catch (_) {}
  }
}

function scheduleRandomChat() {
  if (randomChatTimeout) clearTimeout(randomChatTimeout);

  // Random time between 2.5 minutes (150s) and 5.5 minutes (330s)
  const delay = Math.floor(Math.random() * (330000 - 150000 + 1)) + 150000;

  randomChatTimeout = setTimeout(() => {
    if (bot && bot.entity && !bot.isSleeping) {
      try {
        bot.chat(getRandom(allRandomBanterMessages));
      } catch (_) {}
    }
    scheduleRandomChat();
  }, delay);
}

function cleanupTimers() {
  stopMovementLoop();
  if (reconnectTimeout) {
    clearTimeout(reconnectTimeout);
    reconnectTimeout = null;
  }
  if (randomChatTimeout) {
    clearTimeout(randomChatTimeout);
    randomChatTimeout = null;
  }
}

function scheduleReconnect() {
  cleanupTimers();
  reconnectTimeout = setTimeout(() => {
    createBot();
  }, config.reconnectDelay);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Graceful shutdown handling
process.on('SIGINT', () => {
  console.log('\n[System] Gracefully shutting down...');
  cleanupTimers();
  if (bot) bot.quit();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n[System] Termination signal received...');
  cleanupTimers();
  if (bot) bot.quit();
  process.exit(0);
});

// Start the bot
createBot();
