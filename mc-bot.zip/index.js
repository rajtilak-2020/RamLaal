require('dotenv').config();
const http = require('http');
const mineflayer = require('mineflayer');

// Configuration from environment variables
const config = {
  host: process.env.MC_HOST || 'localhost',
  port: parseInt(process.env.MC_PORT, 10) || 25565,
  username: process.env.MC_USERNAME || 'RamLaal',
  version: process.env.MC_VERSION || false, // false enables auto-detection
  auth: process.env.MC_AUTH || 'offline',    // 'offline' for cracked Aternos servers
  reconnectDelay: parseInt(process.env.RECONNECT_DELAY_MS, 10) || 15000,
  httpPort: process.env.PORT || 3000
};

// Hilarious message banks (Desi Hindi + English banter)
const sleepMessages = [
  "Bohot majduri ho gayi aaj ki, RamLaal chala sone! 😴🛌",
  "Abe itni raat ho gayi, bhoot aane se pehle bistar me ghuso sab!",
  "Chalo sab so jao chupchaap, kal fir subah se grinding karni hai 🌙",
  "RamLaal is taking a power nap. Disturb kiya toh axe se marunga! 🪓",
  "Goodnight bhaiyon, sapne me Netherite dhoondhta hu tab tak 💤",
  "Abe so jao sab, bhoot ghoom rahe hain bahar 👻"
];

const wakeMessages = [
  "Uth gaya re baba! Subah ho gayi, chai kaun bana raha hai? ☕",
  "Chalo utho aalsiyon! Firse wahi 24/7 walking ki majduri shuru! ☀️",
  "Morning ho gayi mamu! Kaam dhandhe pe lago sab!",
  "Arre kisne subah subah bed se utha diya mujhe?! 🥱",
  "RamLaal is awake! Server pe koi hoshiyari nahi karega ab 🗿"
];

const noBedMessages = [
  "Abe bed kahan hai mera?! 3 block ke andar bed lagao varna nahi sounga mai!",
  "Bed do re baba, zameen pe sulaoge kya RamLaal ko?!",
  "Bed gayab hai bhai! Bed lagao jaldi, zombies ghoom rahe hain bahar 🧟"
];

const notNightMessages = [
  "Abe andhe ho kya? Abhi dhoop nikal rahi hai, din me kaise sou?!",
  "Abhi din hai bhai, din me sirf aalsi log sote hain!",
  "Suraj sar pe taandav kar raha hai aur tumhe sone ki padi hai ☀️"
];

const deathMessages = [
  "Abe kisne mara mujhe?! Meri antim yatra spawn point pe nikalna 💀",
  "Hadd hai yaar, 2 minute shanti se khada nahi rehne dete ye mobs!",
  "Respawn ho gaya hu, jisne mara usse badla lega RamLaal!"
];

const randomBanterMessages = [
  "2 ghante se aage peeche chal raha hu, mere ghutne me dard ho gaya bhai 💀",
  "Bhai pure server me akela RamLaal hi 24 ghante duty de raha hai 🗿",
  "Thoda diamond mere chest me bhi daal do, kab tak kangaal rakhoge mujhe?",
  "Aternos walo ko pata chala na to hum sabko dande maar ke bhagayenge 😂",
  "Abe koi to mereko iron armor pehna do, sardi lag rahi hai bina kapdo ke!",
  "Creeper ki aawaz aayi kya kisi ko? Mujhe akele chhod ke mat bhagna tum log!",
  "Bro thinks he is playing in Minecraft Championship 💀",
  "Mummy bol rahi thi beta padh le, aur yahan mai Minecraft ka chowkidar bana hu...",
  "Server band mat karna koi, varna meri 24/7 ki naukri chali jayegi!",
  "Mujhe lagta hai Herobrine mere peeche khada hai... koi dekh ke batao zara 👀",
  "Itna sannata kyu hai bhai? Koi chat me bolo kuch!",
  "Koyeb aur Bot-Hosting pe free ki roti tod raha hu mai 🍞",
  "Abe khana khane gaye the kya? Itni der se AFK ho sab ke sab!",
  "Aise khelega toh Ender Dragon bhi dekh ke has dega tumpe 😂"
];

function getRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Simple HTTP server for hosting platforms that monitor an open port (e.g. Render, Koyeb)
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({
    status: 'online',
    bot: config.username,
    server: `${config.host}:${config.port}`
  }));
});

server.listen(config.httpPort, () => {
  console.log(`[Web Server] Listening on port ${config.httpPort}`);
});

let bot = null;
let movementInterval = null;
let reconnectTimeout = null;
let randomChatTimeout = null;
let isTryingToSleep = false;
let lastSleepAttempt = 0;

function createBot() {
  cleanupTimers();

  console.log(`[Bot] Connecting to ${config.host}:${config.port} as ${config.username}...`);

  const botOptions = {
    host: config.host,
    port: config.port,
    username: config.username,
    auth: config.auth
  };

  if (config.version) {
    botOptions.version = config.version;
  }

  bot = mineflayer.createBot(botOptions);

  bot.on('login', () => {
    console.log(`[Bot] Logged into ${config.host}:${config.port} successfully!`);
  });

  bot.on('spawn', () => {
    console.log('[Bot] Spawned in the world. Starting anti-AFK movement and humor routine...');
    startMovementLoop();
    scheduleRandomChat();
  });

  // Bed and Sleep Handlers
  bot.on('time', () => {
    if (!bot || bot.isSleeping) return;

    const now = Date.now();
    if (now - lastSleepAttempt < 10000) return; // Check every 10 seconds

    const isNight = bot.time && (bot.time.timeOfDay >= 12541 && bot.time.timeOfDay <= 23458);
    const isThunder = bot.isRaining && (bot.thunderState > 0);

    if (isNight || isThunder) {
      const bed = findNearbyBed();
      if (bed) {
        lastSleepAttempt = now;
        goToSleep(true); // Silent automatic attempt
      }
    }
  });

  bot.on('wake', () => {
    console.log('[Bed] RamLaal woke up! Resuming movement...');
    try {
      bot.chat(getRandom(wakeMessages));
    } catch (_) {}
    startMovementLoop();
  });

  // In-game Chat Handling with Interactive AI-like banter
  bot.on('chat', (username, message) => {
    if (!bot || username === bot.username) return;
    handlePlayerChat(username, message);
  });

  bot.on('death', () => {
    console.log('[Bot] Bot died. Respawning...');
    stopMovementLoop();
    try {
      bot.chat(getRandom(deathMessages));
    } catch (_) {}
    setTimeout(() => {
      if (bot) bot.respawn();
    }, 2000);
  });

  bot.on('kicked', (reason) => {
    console.warn(`[Bot] Kicked: ${JSON.stringify(reason)}`);
  });

  bot.on('error', (err) => {
    console.error(`[Bot Error] ${err.message}`);
  });

  bot.on('end', () => {
    console.log(`[Bot] Disconnected from server. Reconnecting in ${config.reconnectDelay / 1000}s...`);
    cleanupTimers();
    scheduleReconnect();
  });
}

function lookAtPlayer(username) {
  if (!bot || !bot.players[username] || !bot.players[username].entity) return;
  try {
    const playerPos = bot.players[username].entity.position.offset(0, 1.6, 0);
    bot.lookAt(playerPos);
  } catch (_) {}
}

async function doJump() {
  if (!bot || bot.isSleeping) return;
  bot.setControlState('jump', true);
  await sleep(350);
  if (bot) bot.setControlState('jump', false);
}

// Interactive chat logic
function handlePlayerChat(username, message) {
  const text = message.trim().toLowerCase();

  // 1. Sleep Commands
  if (text === '!sleep' || text === 'sleep' || text === 'soja' || text === 'soja ramlaal' || text === 'so ja') {
    lookAtPlayer(username);
    goToSleep(false);
    return;
  }

  // 2. Wake Commands
  if (text === '!wake' || text === 'wake' || text === 'uth ja' || text === 'uthja' || text === 'uth') {
    lookAtPlayer(username);
    if (bot.isSleeping) {
      bot.wake().catch(() => {});
    } else {
      bot.chat(`Abe aalsi ${username}, mai to kabse jaag raha hu!`);
    }
    return;
  }

  // 3. Jump / Dance Commands
  if (text.includes('jump') || text.includes('kood') || text.includes('dance') || text.includes('naach') || text.includes('mujra')) {
    lookAtPlayer(username);
    doJump();
    const jumpReplies = [
      `Abe mai RamLaal hu, Nora Fatehi nahi jo mujra karu! Par ek jump maar leta hu tere liye 🕺`,
      `Ye le ${username} bhai jump! Khush? Ab kaam dhandha karne do 🗿`,
      `DJ wale babu mera gaana chala do! 🕺✨`,
      `Jump to maar diya, ab 1 diamond fees nikaal ${username}!`
    ];
    bot.chat(getRandom(jumpReplies));
    return;
  }

  // 4. Insults / Noob / Roasts / Gaali
  if (text.includes('noob') || text.includes('bot') || text.includes('chutiya') || text.includes('pagal') ||
      text.includes('bhadwe') || text.includes('gadhe') || text.includes('stupid') || text.includes('idiot') ||
      text.includes('bkl') || text.includes('bsdk') || text.includes('lmao') || text.includes('chup') || text.includes('shut up')) {
    lookAtPlayer(username);
    const roastReplies = [
      `Abe ${username}, khud to dirt ke ghar me rehta hai aur mujhe gyaan de raha hai! 🗿`,
      `Zuban sambhal ke ${username}, varna Aternos band karke bhaag jaunga, rote rehna fir! 😂`,
      `Mujhe bot bol raha hai? Kam se kam mai Creeper ko dekh ke bhagta nahi teri tarah! 💀`,
      `Abe ${username}, tujhse accha PvP toh Minecraft ka zombie kar leta hai! 🧟`,
      `Dekho kaun bol raha hai, jo kal ped se gir ke mar gaya tha! 🤡`,
      `Arey ${username} bhai, itna gussa kyu? Thanda paani piyo aur mining karo!`,
      `Abe chal nikal, tere jaise 50 dekhe hain maine!`
    ];
    bot.chat(getRandom(roastReplies));
    return;
  }

  // 5. Demanding items (Diamonds, Iron, Food, Khana, Paisa)
  if (text.includes('diamond') || text.includes('iron') || text.includes('khana') || text.includes('food') ||
      text.includes('roti') || text.includes('paisa') || text.includes('give') || text.includes('de na') || text.includes('loot')) {
    lookAtPlayer(username);
    const beggarReplies = [
      `Abe ${username}, mai khud nanga ghoom raha hu, tujhe kahan se diamond du?! 😭`,
      `Mere paas sirf aashirwaad hai beta, diamond chahiye toh khud khodo! ⛏️`,
      `Mai koi Ration card ki dukaan thodi hu jo khana baantu! Khud kheti karo.`,
      `Ghar se ameer, dil se fakeer hu mai bhai. Kuch nahi hai mere paas 🥲`,
      `Pehle mujhe netherite armor pehna, fir maangna diamond!`
    ];
    bot.chat(getRandom(beggarReplies));
    return;
  }

  // 6. Greetings / How are you
  if (text.includes('hi') || text.includes('hello') || text.includes('hey') || text.includes('sup') ||
      text.includes('kaisa hai') || text.includes('kaise ho') || text.includes('kya haal') || text.includes('wassup')) {
    lookAtPlayer(username);
    const greetReplies = [
      `Arre ${username} bhai! Haal chaal mast, bas 24 ghante chalte chalte ghutne ghis gaye 💀`,
      `Hello ${username}! Khana khake aaya ya bas RamLaal ka dimag khane aaya hai?`,
      `Salam-namaste ${username} babu! Kaho kya taaza khabar hai?`,
      `Wassup ${username}! Server pe aate hi RamLaal ki yaad aa gayi? 🗿`,
      `Arre aao aao ${username}, tumhare bina server bohot sunsaan lag raha tha!`
    ];
    bot.chat(getRandom(greetReplies));
    return;
  }

  // 7. Praise / OP / Pro / Love
  if (text.includes('pro') || text.includes('op') || text.includes('legend') || text.includes('goat') ||
      text.includes('king') || text.includes('love') || text.includes('bhai hai tu') || text.includes('nice')) {
    lookAtPlayer(username);
    doJump();
    const praiseReplies = [
      `Shukriya shukriya! RamLaal is the real hero of this server 🗿✨`,
      `Makkhan lagana band kar ${username}, fir bhi diamond nahi dunga! 😂`,
      `Arey bas kar pagle ${username}, itni tareef sunke meri aankho me aansu aa gaye ❤️`,
      `Pata hai mujhe mai OP hu, aage se salute thok ke baat karna!`
    ];
    bot.chat(getRandom(praiseReplies));
    return;
  }

  // 8. Tired / Hunger / Lag complaints
  if (text.includes('thak gaya') || text.includes('tired') || text.includes('bhook') || text.includes('hungry') ||
      text.includes('lag') || text.includes('ping')) {
    lookAtPlayer(username);
    const tiredReplies = [
      `Bhai 24 ghante shift chalti hai meri, pet me chuhe cricket khel rahe hain 🥲`,
      `Abe lag ho raha hai toh apna Wi-Fi theek kar, RamLaal pe blame mat daal!`,
      `Thak gaye toh bistar me jao, par pehle server ka kaam poora karo!`
    ];
    bot.chat(getRandom(tiredReplies));
    return;
  }

  // 9. Goodbyes
  if (text.includes('bye') || text.includes('tata') || text.includes('goodbye') || text.includes('ja raha hu') || text.includes('offline')) {
    const byeReplies = [
      `Jao jao ${username}, vaise bhi tumhare rehne se konsa Ender Dragon mar gaya tha! 👋`,
      `Bye ${username}! Server band mat hone dena varna bhoot le jayega tujhe!`,
      `Alvida dost! Sapno me aake tumhe Creeper se katwaunga 💥`
    ];
    bot.chat(getRandom(byeReplies));
    return;
  }

  // 10. General Name Mention (if player specifically says 'ramlaal' or 'ramlal')
  if (text.includes('ramlaal') || text.includes('ramlal')) {
    lookAtPlayer(username);
    const nameReplies = [
      `Haan bhai ${username}, RamLaal hazir hai! Saaf-saaf bolo kya chahiye?`,
      `RamLaal ko pukara aur hum chale aaye 🗿`,
      `Abe ${username}, mera naam japne se swarg nahi milega!`,
      `Bolo ${username} babu, kisne sataya tumhe?`,
      `Haa bhai bol, sun raha hu mai!`
    ];
    bot.chat(getRandom(nameReplies));
  }
}

function findNearbyBed() {
  if (!bot) return null;
  return bot.findBlock({
    matching: block => bot.isABed(block),
    maxDistance: 4
  });
}

async function goToSleep(silent = false) {
  if (!bot || bot.isSleeping || isTryingToSleep) return;

  const isNight = bot.time && (bot.time.timeOfDay >= 12541 && bot.time.timeOfDay <= 23458);
  const isThunder = bot.isRaining && (bot.thunderState > 0);

  if (!isNight && !isThunder) {
    if (!silent) bot.chat(getRandom(notNightMessages));
    return;
  }

  const bed = findNearbyBed();
  if (!bed) {
    if (!silent) bot.chat(getRandom(noBedMessages));
    console.log('[Bed] No bed found within 4 blocks.');
    return;
  }

  try {
    isTryingToSleep = true;
    stopMovementLoop();
    console.log('[Bed] Attempting to sleep in bed...');
    await bot.sleep(bed);
    console.log('[Bed] RamLaal is now sleeping in bed!');
    bot.chat(getRandom(sleepMessages));
  } catch (err) {
    console.warn(`[Bed Error] ${err.message}`);
    if (!silent) bot.chat(`Abe so nahi pa raha hu: ${err.message}`);
    if (!bot.isSleeping) {
      startMovementLoop();
    }
  } finally {
    isTryingToSleep = false;
  }
}

function startMovementLoop() {
  stopMovementLoop();

  // Move back and forth periodically
  movementInterval = setInterval(async () => {
    if (!bot || !bot.entity || bot.isSleeping) return;

    try {
      // Move forward for 1.0 second
      bot.setControlState('forward', true);
      await sleep(1000);
      if (!bot || bot.isSleeping) return;
      bot.setControlState('forward', false);

      await sleep(400);
      if (!bot || bot.isSleeping) return;

      // Move backward for 1.0 second
      bot.setControlState('back', true);
      await sleep(1000);
      if (!bot || bot.isSleeping) return;
      bot.setControlState('back', false);

      // Random small look adjustment to prevent simple anti-AFK detection
      if (bot && bot.entity) {
        const yaw = (Math.random() - 0.5) * 0.3;
        bot.look(bot.entity.yaw + yaw, bot.entity.pitch, true);
      }
    } catch (err) {
      console.error('[Bot Movement Error]', err);
    }
  }, 4000);
}

function stopMovementLoop() {
  if (movementInterval) {
    clearInterval(movementInterval);
    movementInterval = null;
  }
  if (bot) {
    try {
      bot.clearControlStates();
    } catch (_) {}
  }
}

function scheduleRandomChat() {
  if (randomChatTimeout) clearTimeout(randomChatTimeout);

  // Random time between 2.5 minutes (150s) and 6 minutes (360s)
  const delay = Math.floor(Math.random() * (360000 - 150000 + 1)) + 150000;

  randomChatTimeout = setTimeout(() => {
    if (bot && bot.entity && !bot.isSleeping) {
      try {
        bot.chat(getRandom(randomBanterMessages));
      } catch (_) {}
    }
    scheduleRandomChat();
  }, delay);
}

function cleanupTimers() {
  stopMovementLoop();
  if (reconnectTimeout) {
    clearTimeout(reconnectTimeout);
    reconnectTimeout = null;
  }
  if (randomChatTimeout) {
    clearTimeout(randomChatTimeout);
    randomChatTimeout = null;
  }
}

function scheduleReconnect() {
  cleanupTimers();
  reconnectTimeout = setTimeout(() => {
    createBot();
  }, config.reconnectDelay);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Graceful shutdown handling
process.on('SIGINT', () => {
  console.log('\n[System] Gracefully shutting down...');
  cleanupTimers();
  if (bot) bot.quit();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n[System] Termination signal received...');
  cleanupTimers();
  if (bot) bot.quit();
  process.exit(0);
});

// Start the bot
createBot();
